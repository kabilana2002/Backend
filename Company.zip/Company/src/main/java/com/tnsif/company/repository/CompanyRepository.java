package com.tnsif.company.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.tnsif.company.entity.Company;

public interface CompanyRepository extends JpaRepository<Company, Integer> {
}
