package com.tnsif.company.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.tnsif.company.entity.Company;
import com.tnsif.company.repository.CompanyRepository;

@RestController
@RequestMapping("/companies")
@CrossOrigin(origins = "http://localhost:4200")
public class CompanyController {

    @Autowired
    CompanyRepository repo;

    @GetMapping("/company")
    public Company addCompany() {
    	Company c = new Company("INFO","IT","CHENNAI","1234567890");
        return repo.save(c);
    }

    @GetMapping
    public List<Company> getCompanies() {
        return repo.findAll();
    }
    
    @PostMapping
    public Company createCompany(@RequestBody Company c) {
        return repo.save(c);
    }

    
    @GetMapping("/{id}")
    public Company getCompanyById(@PathVariable Integer id) {
        return repo.findById(id).orElse(null);
    }

    @DeleteMapping("/{id}")
    public void deleteCompany(@PathVariable Integer id) {
        repo.deleteById(id);
    }

    @PutMapping("/{id}")
    public Company updateCompany(@PathVariable Integer id, @RequestBody Company c) {
        c.setCompanyId(id);
        return repo.save(c);
    }
}
