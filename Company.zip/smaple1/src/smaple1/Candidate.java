package smaple1;

public class Candidate {

}
