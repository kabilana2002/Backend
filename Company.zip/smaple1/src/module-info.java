/**
 * 
 */
/**
 * 
 */
module smaple1 {
}